import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { FavoriteService } from './favorite.service';

@Component({
  selector: 'app-movies',
  templateUrl: './favorite.component.html',
  styleUrls: ['./favorite.component.css']
})
export class FavoriteComponent implements OnInit {
  movies = [
    {
      favoriteId: '',
      name: '',
      imdbId: '',
      posterUrl: '',
      imdbRank: ''
    }
  ];
  constructor(private http: HttpClient, private router: Router,  private toastr: ToastrService,  private favoriteService: FavoriteService) { 
    this.getMovies()
      .then(function(values){
      })
      .catch(function(err){});
  }

  ngOnInit(): void {
    
  }

  getMovies(){
    return new Promise((resolve, reject) => {
      this.favoriteService.getMovies().subscribe(
        (response: any) => {
          this.movies = response;
          console.log(this.movies);
        },
        error => {
          reject(null);
        }
      )
    });
  }

  goMovie(movieId: string, favoriteId: string){
    console.log("haci çağırdık seni: ", movieId);
    this.router.navigate(['/detail'], { skipLocationChange: true, state: { imdbId: movieId, favoriteId: favoriteId } });
  }
}
