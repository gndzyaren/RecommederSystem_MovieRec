import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  obLogin = {
    type: 'login',
    userName: '',
    password: '',
    email: ''
  }
  constructor(private http: HttpClient, private router: Router,  private toastr: ToastrService,  private loginService: LoginService) { }

  ngOnInit(): void {
  }

  register(){
    if(this.obLogin.type == 'login')
      this.obLogin.type = 'register';
    else
      this.obLogin.type = 'login';
  }

  

  loginn(){
    return new Promise((resolve, reject) => {
      this.loginService.login(this.obLogin.type, this.obLogin.userName, this.obLogin.password, this.obLogin.email).subscribe(
        (response: any) => {
          if(response == 'true'){
            this.router.navigate(['/home'], { skipLocationChange: true });
            resolve(null);
          }
          else{
            reject(null)
          };
        },
        error => {
          reject(null);
        }
      )
    })
  };
}
