import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { map, catchError} from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';

@Injectable()

export class LoginService {
    constructor(private http: HttpClient, private cookieService: CookieService) { }

    headers = new HttpHeaders({
        "Content-Type": "application/json"
      });

    public login(type: string, userName: string, password: string, email: string):Observable<any>{
        let url = 'https://buraktest.ap.ngrok.io/';
        if(type == 'login'){
            url += 'login';
        }
        else{
            url += 'register'
        };
        let body = {
            email: email, 
            userName: userName,
            password: password
        }
        console.log(url);

        return this.http.post(url, body, {
            headers: this.headers,
            responseType: 'json'
        }).pipe(
            map((response: any) => {
                console.log("ney: ", response)
                if(response && response.hasOwnProperty('code') && response.code ==  0){
                    this.cookieService.set('accessToken', response.accessToken);
                    return 'true';
                }
                else{
                    return 'false';
                }
            }),
            catchError(error => {
                return 'false';
              })
        )
    }
}