import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.css'],
})
export class SidenavListComponent implements OnInit {
  @Output() sidenavClose = new EventEmitter();
  activeSubMenu = 'Root';
  isLogin = false;

  constructor(
    private router: Router,
    private cookieService: CookieService
    ) {}

  ngOnInit() {
    setInterval(() => {
      this.checkAccessToken(); 
      }, 100);
  }

  public onSidenavClose = () => {
    this.sidenavClose.emit();
  };

  public getComedy = () => {
    this.sidenavClose.emit();
    this.router.navigate(['/comedy'], {queryParamsHandling: 'merge',  state: { type: 'comedy' } });
  };

  public getHorror = () => {
    this.router.navigate(['/horror'], {queryParamsHandling: 'merge',  state: { type: 'horror' } });
    this.sidenavClose.emit();
  };

  public getCrime = () => {
    this.sidenavClose.emit();
    this.router.navigate(['/crime'], {queryParamsHandling: 'merge',  state: { type: 'crime' } });
  };

  public getAction = () => {
    this.sidenavClose.emit();
    this.router.navigate(['/action'], {queryParamsHandling: 'merge',  state: { type: 'action' } });
  };

  public getHistory = () => {
    this.sidenavClose.emit();
    this.router.navigate(['/history'], {queryParamsHandling: 'merge', state: { type: 'history' } });
  };

  public login = () => {
    this.sidenavClose.emit();
    this.router.navigate(['/login']);
  }
  
  public logOut = () => {
    this.sidenavClose.emit();
    this.isLogin = false;
    this.cookieService.delete('accessToken');
  }

  public getRecommends = () => {
    this.sidenavClose.emit();
    this.router.navigate(['/recommends'], {queryParamsHandling: 'merge', state: { type: 'recommends' } });
  }

  public getFavorites = () => {
    this.sidenavClose.emit();
    this.router.navigate(['/favorite']);
  }

  public checkAccessToken = () => {
      let accessToken = this.cookieService.get('accessToken');
      if(accessToken != null && accessToken != ''){
        this.isLogin = true;
      }
  }
}
