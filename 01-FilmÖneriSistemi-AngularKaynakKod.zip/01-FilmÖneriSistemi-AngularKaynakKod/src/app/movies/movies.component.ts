import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { MoviesService } from './movies.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {
  type = 'comedy';
  movies = [
    {
      name: '',
      imdbId: '',
      posterUrl: '',
      imdbRank: ''
    }
  ];
  constructor(private http: HttpClient, private router: Router,  private toastr: ToastrService,  private moviesService: MoviesService) { 
    if(this.router.getCurrentNavigation()?.extras.state && this.router.getCurrentNavigation()?.extras?.state?.type){
      this.type = this.router.getCurrentNavigation()?.extras?.state?.type;
      console.log("type: ", this.type);
    }
    this.getMovies(this.type)
      .then(function(values){
      })
      .catch(function(err){});
  }

  ngOnInit(): void {
    
  }

  getMovies(movieType: string){
    console.log("type1: ", this.type);
    return new Promise((resolve, reject) => {
      this.moviesService.getMovies(movieType).subscribe(
        (response: any) => {
          this.movies = response;
          console.log(this.movies);
        },
        error => {
          reject(null);
        }
      )
    });
  }

  goMovie(movieId: string){
    console.log("haci çağırdık seni: ", movieId);
    this.router.navigate(['/detail'], { skipLocationChange: true, state: { imdbId: movieId } });
  }
}
