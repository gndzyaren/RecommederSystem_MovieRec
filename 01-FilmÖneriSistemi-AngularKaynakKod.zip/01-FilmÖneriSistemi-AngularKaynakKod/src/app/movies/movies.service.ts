import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { map, catchError} from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';

@Injectable()

export class MoviesService {
    constructor(private http: HttpClient, private cookieService: CookieService) { }

    headers = new HttpHeaders({
        "Content-Type": "application/json"
      });

    public getMovies(type: string):Observable<any>{
        let token = this.cookieService.get('accessToken');
        let url = 'https://buraktest.ap.ngrok.io/movies?accessToken=' + token + '&category=' + type;
        console.log("url: ", url);
        

        return this.http.get(url, {
            headers: this.headers,
            responseType: 'json'
        }).pipe(
            map((response: any) => {
                console.log("ney: ", response)
                if(response && response.hasOwnProperty('code') && response.code ==  0){
                    console.log("haci: ", response.movieList);
                    return response.movieList;
                }
                else{
                    return [];
                }
            }),
            catchError(error => {
                return 'false';
              })
        )
        
    }
}