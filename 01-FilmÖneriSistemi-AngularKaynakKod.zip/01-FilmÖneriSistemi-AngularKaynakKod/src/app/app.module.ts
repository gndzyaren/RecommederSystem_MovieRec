import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER, NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule ,HttpClient} from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './navigation/header/header.component';
import { SidenavListComponent } from './navigation/sidenav-list/sidenav-list.component';
import { RoutingModule } from './routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LayoutComponent } from './layout/layout.component';
import { MatIconModule } from '@angular/material/icon';
import { MaterialModule } from './material/material.module';
import { MoviesComponent } from './movies/movies.component';
import { ToastrModule } from 'ngx-toastr';
import { MoviesService } from './movies/movies.service';
import { MovieDetailComponent } from './movie-detail/movie-detail.component';
import { MovieService } from './movie-detail/movie.service';
import { LoginComponent } from './login/login.component';
import { LoginService } from './login/login.service';
import { FavoriteComponent } from './favorite/favorite.component';
import { FavoriteService } from './favorite/favorite.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidenavListComponent,
    LayoutComponent,
    MoviesComponent,
    MovieDetailComponent,
    LoginComponent,
    FavoriteComponent
  ],
  imports: [
    BrowserModule,
    BrowserModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    MatIconModule,
    RoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    ToastrModule.forRoot({
      positionClass: 'toast-bottom-right',
      closeButton: true
    }),
  ],
  providers: [
    MoviesService,
    MovieService,
    LoginService,
    FavoriteService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
