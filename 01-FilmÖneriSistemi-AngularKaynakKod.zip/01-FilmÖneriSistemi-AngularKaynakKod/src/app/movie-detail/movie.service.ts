import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { map, catchError} from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';

@Injectable()

export class MovieService {
    constructor(private http: HttpClient, private cookieService: CookieService) { }

    headers = new HttpHeaders({
        'x-rapidapi-key': 'ca473269bamshe778b76a43bf293p1652a8jsn07d9e96b05f6',
        'x-rapidapi-host': 'movie-database-imdb-alternative.p.rapidapi.com'
      });

    public getMovie(imdbId: string):Observable<any>{
        let url = 'https://movie-database-imdb-alternative.p.rapidapi.com/?r=json&i=' + imdbId;
        console.log("url: ", url);
        

        return this.http.get(url, {
            headers: this.headers,
            responseType: 'json'
        }).pipe(
            map((response: any) => {
                console.log("response: ", response)
                return response;
            }),
            catchError(error => {
                return '';
              })
        )
    }

    public addFavorite(name: string, imdbId: string, imdbRating: string, poster: string):Observable<any>{
        let token = this.cookieService.get('accessToken');
        let url = 'https://buraktest.ap.ngrok.io/favorite';
        console.log(url)
        let body = {
            name: name,
            type: 'movie',
            accessToken: token,
            imdbId: imdbId,
            imdbRank: imdbRating,
            posterUrl: poster
        };

        return this.http.post(url, body, {
            headers: new HttpHeaders({
                "Content-Type": "application/json"
            }),
            responseType: 'json'
        })
        .pipe(
            map((response: any) => {
                if(response && response.hasOwnProperty('code') && response.code ==  0){
                    return response.favoriteId;
                }
                else{
                    return 'false';
                }
            }),
            catchError(error => {
                return 'false';
              })
        )
    }

    public deleteFavorite(favoriteId: string):Observable<any>{
        let token = this.cookieService.get('accessToken');
        let url = 'https://buraktest.ap.ngrok.io/favorite?accessToken=' + token + '&favoriteId=' + favoriteId;
        

        return this.http.delete(url, {
            headers: new HttpHeaders({
                "Content-Type": "application/json"
            }),
            responseType: 'json'
        })
        .pipe(
            map((response: any) => {
                if(response && response.hasOwnProperty('code') && response.code ==  0){
                    return 'true';
                }
                else{
                    return 'false';
                }
            }),
            catchError(error => {
                return 'false';
              })
        )
    }
}