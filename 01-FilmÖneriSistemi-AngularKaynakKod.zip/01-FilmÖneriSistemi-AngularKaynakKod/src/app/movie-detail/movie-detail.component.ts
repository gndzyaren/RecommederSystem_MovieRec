import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { MovieService } from './movie.service';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.component.html',
  styleUrls: ['./movie-detail.component.css']
})
export class MovieDetailComponent implements OnInit {
  imdbId = '';
  checked = false;
  favoriteId = '';
  movieDetail = {
    "Title":"",
    "Year":"",
    "Rated":"",
    "Released":"",
    "Runtime":"",
    "Genre":"",
    "Director":"",
    "Writer":"",
    "Actors":"",
    "Plot":"",
    "Language":"",
    "Country":"",
    "Awards":"",
    "Poster":"",
    "Ratings":[],
    "Metascore":"",
    "imdbRating":"",
    "imdbVotes":"",
    "imdbID":"",
    "Type":"",
    "DVD":"",
    "BoxOffice":"",
    "Production":"",
    "Website":"",
    "Response":""
  }

  constructor(private http: HttpClient, private router: Router,  private toastr: ToastrService, private movieService: MovieService) {
    console.log("evvet");
    if(this.router.getCurrentNavigation()?.extras.state && this.router.getCurrentNavigation()?.extras?.state?.imdbId){
      this.imdbId = this.router.getCurrentNavigation()?.extras?.state?.imdbId;
    }
    if(this.router.getCurrentNavigation()?.extras.state && this.router.getCurrentNavigation()?.extras?.state?.favoriteId){
      this.favoriteId = this.router.getCurrentNavigation()?.extras?.state?.favoriteId;
      this.checked = true;
    }
    console.log("evet: ",this.imdbId);
    this.getMovies(this.imdbId)
      .then(function(values){
      })
      .catch(function(err){});
  }

  ngOnInit(): void {
  }

  getMovies(id: string){
    return new Promise((resolve, reject) => {
      this.movieService.getMovie(id).subscribe(
        (response: any) => {
          if(response == ''){

          }
          else{
            this.movieDetail = response;
            console.log(this.movieDetail);
          }
        },
        error => {
          reject(null);
        }
      )
    });
  };

  addFavoriteService(){
    console.log("nasıl")
    return new Promise((resolve, reject) => {
      this.movieService.addFavorite(this.movieDetail.Title, this.movieDetail.imdbID, this.movieDetail.imdbRating, this.movieDetail.Poster).subscribe(
        (response: any) => {
            if(response == 'false'){
              this.checked = false;
              resolve(null);
              
            }
            else{
              this.checked = true;
              this.favoriteId = response;
              resolve(null);
            }
        },
        error => {
          reject(null);
        }
      )
    })
  }

  deleteFavoriteService(){
    console.log("nasıl")
    return new Promise((resolve, reject) => {
      this.movieService.deleteFavorite(this.favoriteId).subscribe(
        (response: any) => {
            if(response == 'true'){
              this.checked = false;
              resolve(null);
            }
            else{
              resolve(null);
            }
        },
        error => {
          reject(null);
        }
      )
    })
  }
}
