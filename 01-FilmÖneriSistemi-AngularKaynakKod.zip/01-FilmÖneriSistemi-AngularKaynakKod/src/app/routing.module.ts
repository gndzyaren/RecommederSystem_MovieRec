import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MoviesComponent } from './movies/movies.component';
import { MovieDetailComponent } from './movie-detail/movie-detail.component';
import { LoginComponent } from './login/login.component';
import { FavoriteComponent } from './favorite/favorite.component';

const routes: Routes = [
    {path: '', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'home', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'comedy', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'horror', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'crime', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'action', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'history', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'recommends', component: MoviesComponent, runGuardsAndResolvers: 'always'},
    {path: 'detail', component: MovieDetailComponent, runGuardsAndResolvers: 'always'},
    {path: 'favorite', component: FavoriteComponent, runGuardsAndResolvers: 'always'},
    {path: 'login', component: LoginComponent, runGuardsAndResolvers: 'always'},
    {path: '**', redirectTo: '/'}
];
 
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'})
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class RoutingModule { }
